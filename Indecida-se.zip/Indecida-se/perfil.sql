create database perfil;

create table user (
username varchar(15) not null,
email varchar(60) not null,
senha varchar(100) not null,
);